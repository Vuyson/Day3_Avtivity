#A4 Part 2(03_average.py)

mark1= float(input("Enter mark1:"))
mark2= float(input("Enter mark2:"))
mark3= float(input("Enter mark3:"))
mark4= float(input("Mark mark4:"))

average= (mark1 + mark2 + mark3 + mark4)/4
print("The average is:", f"{average:.2f}")#Average rounded-of to two decimail places

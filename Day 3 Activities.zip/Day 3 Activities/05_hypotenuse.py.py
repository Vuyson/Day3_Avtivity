import math

try:

    side_a = float(input("Enter the length of side_a (in metres): "))
    side_b = float(input("Enter the length of side_b (in metres): "))

    if side_a <= 0 or side_b <= 0:
        print("Error: Triangle sides must be greater than zero. Negative values or zero are rejected.")
    else:
        
        hypotenuse = math.sqrt(side_a**2 + side_b**2)
        
        print(f"The length of the hypotenuse is: {hypotenuse:.2f} metres")

except ValueError:
    print("Error: Please enter valid numerical values.")
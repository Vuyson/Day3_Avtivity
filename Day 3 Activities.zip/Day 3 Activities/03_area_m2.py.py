#A4 Part 1(03_area_m2.py)

length = float(input("What is the length:"))
width = float(input("What is the width:"))
area= length*width
print("The area is:", f"{area:.2f}")
